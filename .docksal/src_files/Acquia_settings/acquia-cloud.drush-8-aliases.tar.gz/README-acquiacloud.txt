This folder contains two hidden folders named .acquia and .drush. Both of these folders should be placed in the $HOME directory on your system. The .acquia folder contains your Acquia Cloud API credentials and the .drush folder contains your Drush aliases for the sites you currently have access to on Acquia Cloud.

Refer to "About Drush on Acquia Cloud" (https://docs.acquia.com/acquia-cloud/manage/ssh/drush/) for more information."
